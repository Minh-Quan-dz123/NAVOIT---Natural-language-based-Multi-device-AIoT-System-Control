import {Routes, Route, Navigate, Link} from "react-router";
import { useAuth } from "./contexts/AuthContext";

import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import ProfilePage from "./pages/ProfilePage";

import AdminMicrocontrollersPage from "./pages/AdminMicrocontrollersPage";
import AdminMicrocontrollerTypesPage from "./pages/AdminMicrocontrollerTypesPage";
import MicrocontrollersPage from "./pages/MicrocontrollersPage";

import AdminDeviceTypesPage from "./pages/AdminDeviceTypesPage";

import AdminLayout from "./components/AdminLayout";


import ProtectedRoute from "./components/ProtectedRoute";



import './App.css'

// Trang tài khoản hiện tại.
function AccountPage() {
    const { user } = useAuth();

    return (
        <>
            <div className="flex flex-wrap justify-center gap-3 bg-gray-100 px-4 pt-4">
                {/* User và Admin đều được xem MCU của mình */}
                <Link
                    to="/microcontrollers"
                    className="rounded-lg bg-gray-800 px-4 py-2 text-white hover:bg-gray-900"
                >
                    Vi điều khiển của tôi
                </Link>

                {/* Chỉ Admin có liên kết quản trị */}
                {user?.role === "Admin" && (
                    <Link
                        to="/admin/microcontrollers"
                        className="rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
                    >
                        Quản trị hệ thống
                    </Link>
                )}
            </div>

            <ProfilePage />
        </>
    );
}


export default function App() 
{
  return (
    <Routes>
      <Route
        path="/"
        element={<Navigate to="/account" replace />}
      />

      <Route
        path="/login"
        element={<LoginPage />}
      />

      <Route
        path="/register"
        element={<RegisterPage />}
      />

      <Route
        path="/account"
        element={
          <ProtectedRoute>
            <AccountPage  />
          </ProtectedRoute>
        }
      />
      {/* USER quản lý danh sách MCU của mình */}
      <Route
          path="/microcontrollers"
          element={
              <ProtectedRoute>
                  <MicrocontrollersPage />
              </ProtectedRoute>
          }
      />

      {/* ADMIN - Dùng chung AdminLayout */}
        <Route
            path="/admin"
            element={
                <ProtectedRoute requiredRole="Admin">
                    <AdminLayout />
                </ProtectedRoute>
            }
        >
          {/* Mặc định vào trang quản lý MCU */}
          <Route
              index
              element={
                  <Navigate
                      to="/admin/microcontrollers"
                      replace
                  />
              }
          />

          {/* Quản lý loại MCU */}
          <Route
              path="microcontroller-types"
              element={<AdminMicrocontrollerTypesPage />}
                 
              
          />

          {/* Quản lý MCU */}
          <Route
              path="microcontrollers"
              element={<AdminMicrocontrollersPage />}    
          />

          {/* Quản lý loại thiết bị */}
          <Route
              path="device-types"
              element={<AdminDeviceTypesPage />}    
          />
        </Route>
      <Route
        path="*"
        element={<Navigate to="/account" replace />}
      />
    </Routes>
  );
}