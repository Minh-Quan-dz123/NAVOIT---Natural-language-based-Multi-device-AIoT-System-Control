from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, HTTPException, Request

from src.server.config import (
    PREDICTOR_MODE,
    MODEL_CHECKPOINT_PATH,
    VNCORENLP_DIR
)

from src.server.schemas import (
    NaturalCommandRequest,
    ParsedCommand
)

from src.server.inference.predictor import Predictor
from src.server.inference.mock_predictor import MockPredictor
from src.server.inference.phobert_predictor import PhoBERTPredictor


# 1. KHỞI TẠO CÁC THÀNH PHẦN SERVER

@asynccontextmanager
async def lifespan(app: FastAPI):

    predictor: Predictor | None = None

    # Dùng bộ dự đoán giả lập.
    if PREDICTOR_MODE == "mock":
        predictor = MockPredictor()

    # Dùng PhoBERT thật.
    elif PREDICTOR_MODE == "phobert":
        predictor = PhoBERTPredictor(
            checkpoint_path=MODEL_CHECKPOINT_PATH,
            vncorenlp_dir=VNCORENLP_DIR
        )

    # Chưa kích hoạt bộ dự đoán.
    elif PREDICTOR_MODE == "disabled":
        predictor = None

    else:
        raise ValueError(f"PREDICTOR_MODE không hợp lệ: {PREDICTOR_MODE}")

    # Lưu lại để các API dùng chung.
    app.state.predictor = predictor
    app.state.predictor_mode = PREDICTOR_MODE

    print(f"NLP Server started - Predictor: {PREDICTOR_MODE}")

    yield

    print("NLP Server stopped")


# 2. TẠO FASTAPI APPLICATION
app = FastAPI(
    title="Smart Home NLP Server",
    version="0.1.0",
    description="NLP Server cho hệ thống AIoT",
    lifespan=lifespan
)


# 3. HEALTH CHECK
# GET /health
@app.get("/health")
def health(request: Request):

    predictor = request.app.state.predictor

    return {
        "status": "running",
        "predictorMode": request.app.state.predictor_mode,
        "predictorReady": predictor is not None
    }


# 4. PHÂN TÍCH CÂU LỆNH
# POST /api/commands/natural/parse
@app.post("/api/commands/natural/parse", response_model=ParsedCommand)
def parse_natural_command(payload: NaturalCommandRequest, request: Request):

    # 1. Kiểm tra văn bản đầu vào.
    text = payload.text.strip()
    if not text:
        raise HTTPException(status_code=422, detail="Câu lệnh không được để trống.")

    # 2. Lấy Predictor đã khởi tạo.
    predictor = request.app.state.predictor
    if predictor is None:
        raise HTTPException(status_code=503, detail="Bộ dự đoán chưa sẵn sàng.")

    # 3. Phân tích câu lệnh.
    result = predictor.predict(text)

    # 4. Trả kết quả.
    # Chưa gửi MQTT.
    # Chưa cập nhật Device Registry.
    return result

# 7. KHỞI ĐỘNG SERVER TRỰC TIẾP
if __name__ == "__main__":

    uvicorn.run(
        "src.server.main:app",
        host="127.0.0.1",
        port=8000,
        reload=True,
    )

