import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parents[2]

load_dotenv(BASE_DIR / ".env")



# 1. CHỌN BỘ DỰ ĐOÁN

# Có 3 chế độ:
#
# disabled: Chưa bật bộ dự đoán
# mock:     Dùng dữ liệu kiểm thử
# phobert:  Dùng model đã fine-tune

PREDICTOR_MODE = os.getenv(
    "NLP_PREDICTOR_MODE",
    "disabled"
).strip().lower()


# 2. ĐƯỜNG DẪN MODEL
MODEL_CHECKPOINT_PATH = os.getenv(
    "NLP_CHECKPOINT_PATH",
    "checkpoints/best_model.pt"
)


# 3. ĐƯỜNG DẪN VNCORENLP
VNCORENLP_DIR = os.getenv(
    "VNCORENLP_DIR",
    "D:/vncorenlp"
)
